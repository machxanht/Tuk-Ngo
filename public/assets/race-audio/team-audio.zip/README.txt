Original recordings from https://www.youtube.com/watch?v=crZF3hghbgQ
{"nameVi": 39, "nameKm": 10, "historyVi": 3, "historyKm": 0}
Each folder is one 2025 registration, not a race bib. Missing audio stays missing; profiles record exact source ranges, CC evidence and historical sources. Automatic CC/name matching has not received independent listening verification. Copyright remains with the broadcaster.
