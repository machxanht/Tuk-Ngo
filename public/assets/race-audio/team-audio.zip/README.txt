Original recordings from:
https://www.youtube.com/watch?v=crZF3hghbgQ
https://www.youtube.com/watch?v=Y2fp9gYRIZ8
https://www.youtube.com/watch?v=XagC29Eyt_U
https://www.youtube.com/watch?v=tnb7TdUVRkU
{"nameVi": 42, "nameKm": 12, "historyVi": 3, "historyKm": 0}
Each folder is one current registration, not a race bib. Missing audio stays missing; profiles record per-clip source ranges, CC/ASR evidence and historical sources. Automatic CC/ASR/name matching is not independent listening verification. Copyright remains with the broadcaster.
