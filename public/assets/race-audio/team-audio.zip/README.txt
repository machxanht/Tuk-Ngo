Original recordings from:
https://www.youtube.com/watch?v=crZF3hghbgQ
https://www.youtube.com/watch?v=Y2fp9gYRIZ8
https://www.youtube.com/watch?v=XagC29Eyt_U
https://www.youtube.com/watch?v=tnb7TdUVRkU
{"nameVi": 58, "nameKm": 12, "historyVi": 3, "historyKm": 0}
Each folder is one current registration, not a race bib. Missing audio stays missing. Supplied names retain the original bytes and owner-provided labels; these are not independent listening or CC verification. Other profiles retain their original CC/ASR and historical evidence. Copyright remains with the recording owners.
